import { Component,OnInit } from '@angular/core';
import { StudentService } from './../services/student.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  listData : any;
  response : any;
  studentNo : any;
  studentName : any;
  grade : any;
  employee = {};
  list : any;
  form : any;
  constructor(private service : StudentService){
    this.list = false;
    this.form = false;
  }	 

  ngOnInit(){

  }

  loadData(){   
    this.list = true;    
    this.form = false;             
    this.service.list()
    .subscribe(res => this.listData = JSON.parse(res._body)); 
  }
  showForm(){
    this.form = !this.form; 
    this.list = false;       
  }
  addData(){	  
  
	  this.service.add({studentNo:this.studentNo,studentName:this.studentName,grade:this.grade})
      .subscribe(res => alert(res._body));  
      this.loadData();    
  }
  
 public deleteData(item){
    this.service.delete(item).subscribe(res => alert(res._body)); 
    this.loadData();   
  }
}