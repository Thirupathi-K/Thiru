import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class StudentService {

  constructor(private _http: Http) { }

  list() {
    return this._http.get("http://localhost:8080/student/list")
      .map((result : Response) => { console.log(result); return result;}).
	  catch((error : any) => Observable.throw(error.json().error)|| 'Server Error');
  }
  
   add(body: Object) {     
    return this._http.post("http://localhost:8080/student/add",body)
      .map((result :Response) => {console.log(result); return result;}).
	  catch((error : any) => Observable.throw(error.json().error)|| 'Server Error');
  }
  
   delete(body: Object){    
    return this._http.post("http://localhost:8080/student/delete",body)
        .map((result:Response) => {return result;})
        .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
  }

}